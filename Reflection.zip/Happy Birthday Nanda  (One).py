def selamat_ulang_tahun(nama):
    # Pesan selamat ulang tahun
    pesan = f"""
    🎉 Selamat Ulang Tahun, {nama}! 🎉
    
    Hari ini adalah hari spesialmu!
    
    Semoga di usia yang baru ini, kamu semakin ceria, sehat, dan sukses dalam segala hal yang diimpikan.
    Keluarga, terutama Ayah & Ibu selalu mendukungmu dan mencintaimu.
    
    Ingatlah, setiap langkah yang kamu ambil adalah bagian dari perjalanan yang indah.
    Selamat berpetualang dan raih semua mimpi-mimpimu!
    
    Dengan penuh cinta,
    Ayah & Ibu yang selalu menyayangimu dimanapun kamu berada. 💝💝💝
    """
    
    return pesan

# Nama yang akan dirayakan
nama_ananda = "Mochammad Irfan Mufarrid Ramadhan (Ananda Ivan Ramadhan)"

# Mencetak pesan selamat ulang tahun
print(selamat_ulang_tahun(nama_ananda))